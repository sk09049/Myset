

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class HomeServlet
 */
@WebServlet("/HomeServlet")
@MultipartConfig
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("/WEB-INF/views/sample.html").include(request, response); 
		request.getRequestDispatcher("/WEB-INF/views/file.html").include(request, response); 

	response.setContentType("text/html");
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/views/sample.html").include(request, response); 
		request.getRequestDispatcher("/WEB-INF/views/retrive.html").include(request, response); 
		
		
		// TODO Auto-generated method stub
       response.setContentType("text/html;charset=UTF-8");

		 Part file =  request.getPart("file");

		 System.out.println(file);
		try {
			Connection con=FileUpload.connect();
			PreparedStatement ps1 = con.prepareStatement("delete from fileupload where id=?");
ps1.setInt(1, 1);
ps1.executeUpdate();
			PreparedStatement ps = con.prepareStatement("insert into fileupload values(?,?)");
		ps.setInt(1,1);
		ps.setBinaryStream(2,file.getInputStream(),(int)file.getSize());
		ps.executeUpdate();
		
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}

}
