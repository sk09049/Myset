import java.sql.*;
public class FileUpload {
	public static Connection connect() throws ClassNotFoundException, SQLException {

		 Class.forName("com.mysql.jdbc.Driver");
        
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test1", "root", "");
		System.out.println("done");
		return con;
	}
	
	public static void main(String[] args) {
		try {
			connect();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
