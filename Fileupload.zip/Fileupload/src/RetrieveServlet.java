

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 * Servlet implementation class RetrieveServlet
 */
@WebServlet("/RetriveServlet")
public class RetrieveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RetrieveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	       response.setContentType("text/html;charset=UTF-8");

		
		
		try {
			Connection con=FileUpload.connect();
			
			 PreparedStatement ps = con.prepareStatement("select file from fileupload where id = ?");
	            ps.setInt(1,1 );
	            ResultSet rs = ps.executeQuery();
	            rs.next();
	            Blob b = rs.getBlob("file");
	            response.setContentType("text/html");
	            response.setContentLength((int) b.length());
	            InputStream is = b.getBinaryStream();
	            OutputStream os = response.getOutputStream();
	            byte buf[] = new byte[(int) b.length()];
	            is.read(buf);
	            os.write(buf);
	            //out.println(b);


		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
